/**
 *******************************************************************
 * Lesson 13 - "EEPROM"
 *
 * This lesson will provide code for writing and reading a single byte onto
 * the on-board EEPROM. EEPROM is non-volatile memory, meaning that it does
 * not lose its value when power is shut off. This is unlike RAM, which will
 * lose its value when no power is applied. The EEPROM is useful for storing
 * variables that must still be present during no power.
 * It is also convenient to use if the entire RAM space is used up.
 * Writes and reads to the EEPROM are practically instant and are much faster
 * than program memory operations.

 * Press the switch to save the LED state and then disconnect the power. When
 * power is then applied again, the program will start with that same LED lit.

 * When the lesson is first programmed, no LEDs will light up even with movement
 * of the POT. When the switch is pressed, the corresponding LED will be lit and
 * then the PIC will go to sleep until the switch is pressed again. Each press of
 * the switch saves the ADC value into EEPROM. The PIC uses interrupts to wake up
 * from sleep, take an ADC reading, save to EEPROM, and then goes back to sleep.
 *
 * PIC: 18F14K22
 * Compiler: XC8 v1.00
 * IDE: MPLABX v1.10
 *
 * Board: PICkit 3 Low Pin Count Demo Board
 * Date: 6.1.2012
 *
 * *******************************************************************
 * See Low Pin Count Demo Board User's Guide for Lesson Information*
 * ******************************************************************
 */

#include <htc.h>                         //PIC hardware mapping
#define _XTAL_FREQ 500000                //Used by the compiler for the delay_ms(x) macro

#define DOWN        0
#define UP          1

#define SWITCH      PORTAbits.RA2

//config bits that are part-specific for the PIC16F1829
__CONFIG(1, FOSC_IRC & PLLEN_OFF & FCMEN_OFF);
__CONFIG(2, PWRTEN_ON & BOREN_OFF & WDTEN_OFF);
__CONFIG(3, HFOFST_OFF & MCLRE_OFF);
__CONFIG(4, STVREN_ON & LVP_OFF & DEBUG_ON);
__CONFIG(5, CP0_OFF & CP1_OFF & CPB_OFF & CPD_OFF);
__CONFIG(6, WRT0_OFF & WRT1_OFF & WRTC_OFF & WRTB_OFF & WRTD_OFF);
__CONFIG(7, EBTR0_OFF & EBTR1_OFF & EBTRB_OFF);


unsigned char adc(void);                    //prototype

    /* -------------------LATC-----------------
     * Bit#:  -7---6---5---4---3---2---1---0---
     * LED:   ---------------|DS4|DS3|DS2|DS1|-
     *-----------------------------------------
     */

void main(void) {
    OSCCON = 0b00100010;                 //500KHz clock speed
    TRISC = 0;                           //all LED pins are outputs
    LATC = 0;                            //init all LEDs OFF

    TRISAbits.TRISA2 = 1;                //switch input
    ANSELbits.ANS2 = 0;                  //digital input for switch

    TRISAbits.TRISA4 = 1;                //Potentiamtor is connected to RA4...set as input
    ANSELbits.ANS3 = 1;                  //analog input - different than pic16 syntax
    ADCON0 = 0b00001101;                 //select RA4 as source of ADC, which is AN3, and enable the module
    ADCON2 = 0b00000001;                 //left justified - FOSC/8 speed

    //setup interrupt on change for the switch
    INTCONbits.RABIE = 1;               //enable interrupt on change global
    IOCAbits.IOCA2 = 1;                 //when SW1 is pressed/released, enter the ISR

    RCONbits.IPEN = 0;                  //disable interrupt priorites
    INTCONbits.GIE = 1;                 //enable global interupts

    while (1) {
        LATC = eeprom_read(0x00);       //load whatever is in EEPROM to the LATCH
        SLEEP();                        //sleep until button is pressed
    }

}

unsigned char adc(void) {
    __delay_us(5);                      //wait for ADC charging cap to settle
    GO = 1;
    while (GO) continue;                //wait for conversion to be finished

    return ADRESH;                      //grab the top 8 MSbs

}

void interrupt ISR(void) {
    unsigned char adc_value = 0;
    
    if (INTCONbits.RABIF) {             //SW1 was just pressed
        INTCONbits.RABIF = 0;           //must clear the flag in software
        __delay_ms(5);                  //debounce by waiting and seeing if still held down
        if (SWITCH == DOWN) {
            adc_value = adc();          //get the ADC value from the POT
            adc_value >>= 4;            //save only the top 4 MSbs

            LATC = adc_value;
                                        //EEPROM is non-volatile, meaning that it can retain its value when no power is applied
            eeprom_write(0x00, adc_value); //save the value to EEPROM and go back to sleep!
        }
    }
}